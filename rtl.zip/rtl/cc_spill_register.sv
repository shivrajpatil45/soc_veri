// Copyright 2018 ETH Zurich and University of Bologna.
//
// Copyright and related rights are licensed under the Solderpad Hardware
// License, Version 0.51 (the "License"); you may not use this file except in
// compliance with the License. You may obtain a copy of the License at
// http://solderpad.org/licenses/SHL-0.51. Unless required by applicable law
// or agreed to in writing, software, hardware and materials distributed under
// this License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
// CONDITIONS OF ANY KIND, either express or implied. See the License for the
// specific language governing permissions and limitations under the License.
//
// Fabian Schuiki <fschuiki@iis.ee.ethz.ch>


/// Wrapper around the flushable spill register to maintain back-ward
/// compatibility.
module cc_spill_register #(
  parameter type data_t = logic,
  parameter bit  Bypass = 1'b0     // make this spill register transparent
) (
  input  logic  clk_i   , // Clock
  input  logic  rst_ni  , // Asynchronous reset active low
  input  logic  clr_i   , // Synchronous clear active high
  input  logic  valid_i ,
  output logic  ready_o ,
  input  data_t data_i  ,
  output logic  valid_o ,
  input  logic  ready_i ,
  output data_t data_o
);

  cc_spill_register_flushable #(
    .data_t(data_t),
    .Bypass(Bypass)
  ) spill_register_flushable_i (
    .clk_i,
    .rst_ni,
    .clr_i,
    .valid_i,
    .flush_i(1'b0),
    .ready_o,
    .data_i,
    .valid_o,
    .ready_i,
    .data_o
  );

endmodule
