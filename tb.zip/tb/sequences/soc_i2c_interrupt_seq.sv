`ifndef SOC_I2C_INTERRUPT_SEQ_SV
`define SOC_I2C_INTERRUPT_SEQ_SV

class soc_i2c_interrupt_seq extends soc_base_seq;
  `uvm_object_utils(soc_i2c_interrupt_seq)

  uvm_sequencer_base wr_seqr;
  uvm_sequencer_base rd_seqr;

  parameter bit [31:0] I2C_BASE = 32'h4000_1000;
  parameter bit [31:0] I2C_PRER = I2C_BASE + 32'h00;
  parameter bit [31:0] I2C_CTR  = I2C_BASE + 32'h04;
  parameter bit [31:0] I2C_RX   = I2C_BASE + 32'h08;
  parameter bit [31:0] I2C_SR   = I2C_BASE + 32'h0C;
  parameter bit [31:0] I2C_TX   = I2C_BASE + 32'h10;
  parameter bit [31:0] I2C_CR   = I2C_BASE + 32'h14;

  parameter bit [7:0] CMD_START_WRITE = 8'h90; // STA=1, WR=1
  parameter bit [7:0] CMD_STOP_WRITE  = 8'h50; // STO=1, WR=1
  parameter bit [7:0] CMD_IACK        = 8'h01; // IACK=1 (Clear Interrupt Flag)

  function new(string name = "soc_i2c_interrupt_seq");
    super.new(name);
  endfunction

  // Task: wait for the byte transfer to finish, then clear the interrupt flag
  task wait_and_clear_interrupt();
    bit [31:0] sr_val;

    // Small delay to let the core register the command and assert TIP
    #200ns;

    // Wait until TIP (bit 1) drops back to 0
    do begin
      #100ns;
      reg_read(I2C_SR, sr_val, rd_seqr);
    end while (sr_val[1] == 1'b1);

    `uvm_info("I2C_INT_SEQ", $sformatf("Transfer complete! SR=0x%02X. Writing IACK to clear interrupt...", sr_val[7:0]), UVM_LOW)
    // Clear Interrupt Flag via Command Register
    reg_write(I2C_CR, {24'h0, CMD_IACK}, wr_seqr);
  endtask

  virtual task body();
    bit [6:0] tgt_addr  = 7'h68;
    bit [7:0] test_data = 8'h5A;

    `uvm_info("I2C_INT_SEQ", "=== Starting I2C Interrupt Transfer Sequence ===", UVM_LOW)

    // 1. Prescaler
    reg_write(I2C_PRER, 32'h0000_0004, wr_seqr);

    // 2. Enable Core and Interrupts (EN=1, IEN=1 -> 0xC0)
    reg_write(I2C_CTR, 32'h0000_00C0, wr_seqr);

    // 3. Send START + Address (WR)
    `uvm_info("I2C_INT_SEQ", $sformatf("Sending START + Target Address 0x%02X (WR)", tgt_addr), UVM_LOW)
    reg_write(I2C_TX, {24'h0, tgt_addr, 1'b0}, wr_seqr);
    reg_write(I2C_CR, {24'h0, CMD_START_WRITE}, wr_seqr);
    wait_and_clear_interrupt();

    // 4. Send Data + STOP
    `uvm_info("I2C_INT_SEQ", $sformatf("Sending Data 0x%02X + STOP", test_data), UVM_LOW)
    reg_write(I2C_TX, {24'h0, test_data}, wr_seqr);
    reg_write(I2C_CR, {24'h0, CMD_STOP_WRITE}, wr_seqr);
    wait_and_clear_interrupt();

    `uvm_info("I2C_INT_SEQ", "=== I2C Interrupt Transfer Successfully Completed ===", UVM_LOW)
  endtask
endclass

`endif
