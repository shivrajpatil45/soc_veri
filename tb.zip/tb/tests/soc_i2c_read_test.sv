`ifndef SOC_I2C_READ_TEST_SV
`define SOC_I2C_READ_TEST_SV

class soc_i2c_read_test extends soc_base_test;
  `uvm_component_utils(soc_i2c_read_test)

  function new(string name = "soc_i2c_read_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  virtual task run_phase(uvm_phase phase);
    soc_i2c_read_seq master_rd_seq;
    i3c_target_readOperationWith8bitsData_seq tgt_rd_seq;

    phase.raise_objection(this);

    master_rd_seq = soc_i2c_read_seq::type_id::create("master_rd_seq");
    tgt_rd_seq    = i3c_target_readOperationWith8bitsData_seq::type_id::create("tgt_rd_seq");

    master_rd_seq.wr_seqr = env.axi_master_env.axi4LiteWriteMasterEnv.axi4LiteMasterWriteAgent[0].axi4LiteMasterWriteSequencer;
    master_rd_seq.rd_seqr = env.axi_master_env.axi4LiteReadMasterEnv.axi4LiteMasterReadAgent[0].axi4LiteMasterReadSequencer;

    fork
      tgt_rd_seq.start(env.i3c_tgt_agent.i3c_target_seqr_h);
      master_rd_seq.start(null);
    join

    phase.drop_objection(this);
  endtask
endclass

`endif
