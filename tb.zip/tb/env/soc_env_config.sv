`ifndef SOC_ENV_CONFIG_SV
`define SOC_ENV_CONFIG_SV

class soc_env_config extends uvm_object;
  `uvm_object_utils(soc_env_config)

  bit has_axi_master = 1'b1;
  bit has_i2c_slave  = 1'b0; // Start with 0 for register sanity, then toggle
  bit has_uart_slave = 1'b0;
  bit has_spi_slave  = 1'b0;

  function new(string name = "soc_env_config");
    super.new(name);
  endfunction
endclass

`endif
