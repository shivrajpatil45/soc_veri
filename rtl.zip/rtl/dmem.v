module pragya_dmem
(
    input         clk_in,

    input         dm_req_in,
    input         dm_wen_in,
    input  [3:0]  dm_be_in,

    input  [31:0] dm_addr_in,
    input  [31:0] dm_wdata_in,

    output  [31:0] dm_rdata_out
);

reg [7:0] memory [0:256];

integer i;

initial begin
       
    for(i=0;i<256;i=i+1)
        memory[i]=0;
end

always @(posedge clk_in)
begin

    // STORE
    if(dm_req_in && dm_wen_in)
    begin

        if(dm_be_in[0])
            memory[dm_addr_in] <= dm_wdata_in[7:0];

        if(dm_be_in[1])
            memory[dm_addr_in+1] <= dm_wdata_in[15:8];

        if(dm_be_in[2])
            memory[dm_addr_in+2] <= dm_wdata_in[23:16];

        if(dm_be_in[3])
            memory[dm_addr_in+3] <= dm_wdata_in[31:24];
    end

    // LOAD
    

end
assign dm_rdata_out = {memory[dm_addr_in+3], memory[dm_addr_in+2], memory[dm_addr_in+1], memory[dm_addr_in]};
   


endmodule
