`ifndef SOC_ENV_INCLUDED_
`define SOC_ENV_INCLUDED_

class soc_env extends uvm_env;
  `uvm_component_utils(soc_env)

  // AXI VIP Master Environment & Configurations
  Axi4LiteMasterEnv             axi_master_env;
  Axi4LiteMasterEnvConfig       axi_env_cfg;
  Axi4LiteWriteMasterEnvConfig  axi_write_env_cfg;
  Axi4LiteReadMasterEnvConfig   axi_read_env_cfg;
  Axi4LiteMasterWriteAgentConfig axi_write_agent_cfg[];
  Axi4LiteMasterReadAgentConfig  axi_read_agent_cfg[];

  // I3C/I2C Target Agent & Configuration
  i3c_target_agent        i3c_tgt_agent;
  i3c_target_agent_config i3c_tgt_cfg;

  function new(string name = "soc_env", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  virtual function void build_phase(uvm_phase phase);
    super.build_phase(phase);

    // =========================================================
    // 1. Configure AXI Master VIP
    // =========================================================
    axi_env_cfg       = Axi4LiteMasterEnvConfig::type_id::create("axi_env_cfg");
    axi_write_env_cfg = Axi4LiteWriteMasterEnvConfig::type_id::create("axi_write_env_cfg");
    axi_read_env_cfg  = Axi4LiteReadMasterEnvConfig::type_id::create("axi_read_env_cfg");

    // Write Master Env & Agent Config
    axi_write_env_cfg.no_of_masters = 1;
    axi_write_agent_cfg = new[1];
    axi_write_agent_cfg[0] = Axi4LiteMasterWriteAgentConfig::type_id::create("axi_write_agent_cfg[0]");
    axi_write_agent_cfg[0].isActive = UVM_ACTIVE;
    axi_write_agent_cfg[0].hasCoverage = Axi4LiteWriteMasterGlobalPkg::HAS_COVERAGE;
    axi_write_agent_cfg[0].defaultStateBready = Axi4LiteWriteMasterGlobalPkg::DEFAULT_BREADY;
    axi_write_agent_cfg[0].minAddressRange = Axi4LiteWriteMasterGlobalPkg::MIN_ADDRESS;
    axi_write_agent_cfg[0].maxAddressRange = Axi4LiteWriteMasterGlobalPkg::MAX_ADDRESS;
    axi_write_agent_cfg[0].maxDelayForAwready = Axi4LiteMasterWriteAssertCoverParameter::MAX_DELAY_READY;
    axi_write_agent_cfg[0].maxDelayForWready = Axi4LiteMasterWriteAssertCoverParameter::MAX_DELAY_READY;
    axi_write_agent_cfg[0].maxDelayForBvalid = Axi4LiteMasterWriteAssertCoverParameter::MAX_DELAY_BVALID;
    axi_write_agent_cfg[0].toggleBready = Axi4LiteWriteMasterGlobalPkg::TOGGLE_BREADY;
    axi_write_agent_cfg[0].enableOutstandingTransaction = Axi4LiteWriteMasterGlobalPkg::ENABLE_OUTSTANDINGTX;
    axi_write_agent_cfg[0].maxLimitOfOutstandingTx = Axi4LiteWriteMasterGlobalPkg::MAXLIMITOF_OUTSTANDINGTX;
    axi_write_agent_cfg[0].noOfOutstandingTx = Axi4LiteWriteMasterGlobalPkg::NO_OF_OUTSTANDINGTX;
    axi_write_env_cfg.axi4LiteMasterWriteAgentConfig = axi_write_agent_cfg;

    uvm_config_db#(Axi4LiteMasterWriteAgentConfig)::set(this, "*", "Axi4LiteMasterWriteAgentConfig[0]", axi_write_agent_cfg[0]);
    uvm_config_db#(Axi4LiteWriteMasterEnvConfig)::set(this, "*", "Axi4LiteWriteMasterEnvConfig", axi_write_env_cfg);

    // Read Master Env & Agent Config
    axi_read_env_cfg.no_of_masters = 1;
    axi_read_agent_cfg = new[1];
    axi_read_agent_cfg[0] = Axi4LiteMasterReadAgentConfig::type_id::create("axi_read_agent_cfg[0]");
    axi_read_agent_cfg[0].isActive = UVM_ACTIVE;
    axi_read_agent_cfg[0].hasCoverage = Axi4LiteReadMasterGlobalPkg::HAS_COVERAGE;
    axi_read_agent_cfg[0].defaultStateRready = Axi4LiteReadMasterGlobalPkg::DEFAULT_RREADY;
    axi_read_agent_cfg[0].minAddressRange = Axi4LiteReadMasterGlobalPkg::MIN_ADDRESS;
    axi_read_agent_cfg[0].maxAddressRange = Axi4LiteReadMasterGlobalPkg::MAX_ADDRESS;
    axi_read_agent_cfg[0].maxDelayForArready = Axi4LiteMasterReadAssertCoverParameter::MAX_DELAY_READY;
    axi_read_agent_cfg[0].maxDelayForRvalid = Axi4LiteMasterReadAssertCoverParameter::MAX_DELAY_RVALID;
    axi_read_agent_cfg[0].toggleRready = Axi4LiteReadMasterGlobalPkg::TOGGLE_RREADY;
    axi_read_agent_cfg[0].enableOutstandingTransaction = Axi4LiteReadMasterGlobalPkg::ENABLE_OUTSTANDINGTX;
    axi_read_agent_cfg[0].maxLimitOfOutstandingTx = Axi4LiteReadMasterGlobalPkg::MAXLIMITOF_OUTSTANDINGTX;
    axi_read_agent_cfg[0].noOfOutstandingTx = Axi4LiteReadMasterGlobalPkg::NO_OF_OUTSTANDINGTX;
    axi_read_env_cfg.axi4LiteMasterReadAgentConfig = axi_read_agent_cfg;

    uvm_config_db#(Axi4LiteMasterReadAgentConfig)::set(this, "*", "Axi4LiteMasterReadAgentConfig[0]", axi_read_agent_cfg[0]);
    uvm_config_db#(Axi4LiteReadMasterEnvConfig)::set(this, "*", "Axi4LiteReadMasterEnvConfig", axi_read_env_cfg);

    // Overall Master Env Config
    axi_env_cfg.axi4LiteWriteMasterEnvConfig = axi_write_env_cfg;
    axi_env_cfg.axi4LiteReadMasterEnvConfig  = axi_read_env_cfg;
    uvm_config_db#(Axi4LiteMasterEnvConfig)::set(this, "*", "Axi4LiteMasterEnvConfig", axi_env_cfg);

    axi_master_env = Axi4LiteMasterEnv::type_id::create("axi_master_env", this);

    // =========================================================
    // 2. Configure and create I3C/I2C Target Agent
    // =========================================================
    i3c_tgt_cfg = i3c_target_agent_config::type_id::create("i3c_tgt_cfg");
    i3c_tgt_cfg.isActive = UVM_ACTIVE;
    i3c_tgt_cfg.targetAddress = TARGET0_ADDRESS; // 7'h68
    uvm_config_db#(i3c_target_agent_config)::set(this, "*", "i3c_target_agent_config", i3c_tgt_cfg);

    i3c_tgt_agent = i3c_target_agent::type_id::create("i3c_tgt_agent", this);
  endfunction

endclass : soc_env

`endif
