`ifndef SOC_BASE_SEQ_SV
`define SOC_BASE_SEQ_SV

class soc_base_seq extends uvm_sequence #(uvm_sequence_item);
  `uvm_object_utils(soc_base_seq)

  function new(string name = "soc_base_seq");
    super.new(name);
  endfunction

  task reg_write(input bit [31:0] addr, input bit [31:0] data, input uvm_sequencer_base seqr);
    Axi4LiteMasterWrite32bitsTransferSeq wr_seq;
    wr_seq = Axi4LiteMasterWrite32bitsTransferSeq::type_id::create("wr_seq");

    wr_seq.awprotSeq.rand_mode(0);

    wr_seq.awaddrSeq          = addr;
    wr_seq.wdataSeq           = data;
    wr_seq.wstrbSeq           = 4'b1111;
    wr_seq.awprotSeq          = awprotEnum'(3'b010); // Data access, non-secure
    wr_seq.delayForAwvalidSeq = 0;
    wr_seq.delayForWvalidSeq  = 0;
    wr_seq.delayForBreadySeq  = 0;

    wr_seq.start(seqr);
  endtask

  task reg_read(input bit [31:0] addr, output bit [31:0] data, input uvm_sequencer_base seqr);
    Axi4LiteMasterRead32bitsTransferSeq rd_seq;
    rd_seq = Axi4LiteMasterRead32bitsTransferSeq::type_id::create("rd_seq");

    rd_seq.arprotSeq.rand_mode(0);

    rd_seq.araddrSeq          = addr;
    rd_seq.arprotSeq          = arprotEnum'(3'b010);
    rd_seq.delayForArvalidSeq = 0;
    rd_seq.delayForRreadySeq  = 0;

    rd_seq.start(seqr);
    data = rd_seq.req.rdata;
  endtask

endclass

`endif
