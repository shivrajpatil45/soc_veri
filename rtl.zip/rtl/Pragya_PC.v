`timescale 1ns / 1ps

module pc_unit #(
    parameter RESET_PC = 32'h00000000)
    (input         clk,
    input         rst,
    input         stall,
    input         branch_taken_in,                // 0: PC+4, 1: Branch/Jump target
    input  [31:0] pc_target,         // Branch/Jump target address

// Machine-mode PC control
    input  [1:0]  pc_src_in,
    input  [31:0] epc_in,
    input  [31:0] trap_address_in,
    
    output reg [31:0] pc,                // Current PC
    output     [31:0] pc_plus4,          // PC + 4
    output            misaligned_instr_out
);

    //========================================================
    // PC source encoding
    // Same encoding as pragya_machine_control
    //========================================================
    localparam PC_BOOT = 2'b00;
    localparam PC_EPC  = 2'b01;
    localparam PC_TRAP = 2'b10;
    localparam PC_NEXT = 2'b11;

    // Internal next PC signal
    reg [31:0] pc_next;
    wire [31:0] normal_pc_next;

    // PC + 4
    assign pc_plus4 = pc + 32'd4;

    // Next PC selection
    //assign pc_next = (branch_taken_in) ? pc_target : pc_plus4;
    assign normal_pc_next = branch_taken_in ? pc_target : pc_plus4;
    
    //========================================================
    // Machine-mode PC MUX
    //========================================================
    always @(*) begin

        case (pc_src_in)

            // Reset / boot
            PC_BOOT:
                pc_next = RESET_PC;

            // MRET
            PC_EPC:
                pc_next = epc_in;

            // Exception / interrupt
            PC_TRAP:
                pc_next = trap_address_in;

            // Normal instruction execution
            PC_NEXT:
                pc_next = normal_pc_next;

            default:
                pc_next = normal_pc_next;

        endcase
    end


assign misaligned_instr_out = branch_taken_in && (pc_target[1:0] != 2'b00);
    
    // PC Register
    always @(posedge clk or posedge rst) begin
        if (rst)
            pc <= RESET_PC;    // Boot address
            
        else if (pc_src_in == PC_TRAP)
        pc <= trap_address_in;       // Trap/exception → mtvec

        else if (pc_src_in == PC_EPC)
        pc <= epc_in;                // MRET → mepc    
        
        else if (!stall)
            pc <= pc_next;
    end

endmodule