`ifndef SOC_I2C_REG_SEQ_SV
`define SOC_I2C_REG_SEQ_SV

class soc_i2c_reg_seq extends soc_base_seq;
  `uvm_object_utils(soc_i2c_reg_seq)

  // Sequencer handles passed from test
  uvm_sequencer_base wr_seqr;
  uvm_sequencer_base rd_seqr;

  // I2C APB Register Offsets (PADDR[5:2])
  // 0x4000_1000: Clock Prescaler (16-bit)
  // 0x4000_1004: Control Register (CTR)
  // 0x4000_1008: Receive Register (RX)
  // 0x4000_100C: Status Register (SR)
  // 0x4000_1010: Transmit Register (TX)
  // 0x4000_1014: Command Register (CR)
  parameter bit [31:0] I2C_BASE   = 32'h4000_1000;
  parameter bit [31:0] I2C_PRER   = I2C_BASE + 32'h00;
  parameter bit [31:0] I2C_CTR    = I2C_BASE + 32'h04;
  parameter bit [31:0] I2C_TX     = I2C_BASE + 32'h10;

  function new(string name = "soc_i2c_reg_seq");
    super.new(name);
  endfunction

  virtual task body();
    bit [31:0] rdata;

    `uvm_info("I2C_REG_TEST", "=== Starting I2C APB Register Test ===", UVM_LOW)

    // -------------------------------------------------------------
    // Step 1: Prescaler Register Test (16-bit write & readback)
    // -------------------------------------------------------------
    `uvm_info("I2C_REG_TEST", "--- Step 1: Write and Read back Prescaler (0x40001000) ---", UVM_LOW)
    reg_write(I2C_PRER, 32'h0000_1234, wr_seqr);
    reg_read(I2C_PRER, rdata, rd_seqr);

    if ((rdata & 32'h0000_FFFF) == 32'h1234)
      `uvm_info("I2C_REG_TEST", $sformatf("Prescaler Match! Read Data: 0x%04X", rdata[15:0]), UVM_LOW)
    else
      `uvm_error("I2C_REG_TEST", $sformatf("Prescaler Mismatch! Expected 0x55AA, got 0x%04X", rdata[15:0]))

    // -------------------------------------------------------------
    // Step 2: Control Register Test (Core Enable & Interrupt Enable)
    // -------------------------------------------------------------
    `uvm_info("I2C_REG_TEST", "--- Step 2: Enable Core & Interrupts via CTR (0x40001004) ---", UVM_LOW)
    reg_write(I2C_CTR, 32'h0000_00C0, wr_seqr); // Bit 7: Core En, Bit 6: IEN
    reg_read(I2C_CTR, rdata, rd_seqr);

    if ((rdata & 32'h0000_00FF) == 32'hC0)
      `uvm_info("I2C_REG_TEST", $sformatf("CTR Core & IRQ Enable Verified! Read Data: 0x%02X", rdata[7:0]), UVM_LOW)
    else
      `uvm_error("I2C_REG_TEST", $sformatf("CTR Verification Failed! Expected 0xC0, got 0x%02X", rdata[7:0]))

    // -------------------------------------------------------------
    // Step 3: Transmit Register Test (0x40001010)
    // -------------------------------------------------------------
    `uvm_info("I2C_REG_TEST", "--- Step 3: Write and Read back TX Register (0x40001010) ---", UVM_LOW)
    reg_write(I2C_TX, 32'h0000_00A5, wr_seqr);
    reg_read(I2C_TX, rdata, rd_seqr);

    if ((rdata & 32'h0000_00FF) == 32'hA5)
      `uvm_info("I2C_REG_TEST", $sformatf("TX Register Match! Read Data: 0x%02X", rdata[7:0]), UVM_LOW)
    else
      `uvm_error("I2C_REG_TEST", $sformatf("TX Register Mismatch! Expected 0xA5, got 0x%02X", rdata[7:0]))

    `uvm_info("I2C_REG_TEST", "=== I2C APB Register Test Completed Successfully ===", UVM_LOW)
  endtask
endclass

`endif
