`include "obi/typedef.svh"
`include "obi/assign.svh"
`include "common_cells/registers.svh"
`include "axi/typedef.svh"
`include "axi/assign.svh"

import obi_pkg::*;
import axi_pkg::*;
import clint_reg_pkg::*; 

module axi_bus  (
    input  logic        pg_riscv32_mp_clk_in,
    input  logic        pg_riscv32_mp_rst_in,
	input  logic        ext_irq_in,

    // =======================================================
    // AXI4 Master Interface (Tied off for Demux Testing)
    // =======================================================
    output logic        axi_awvalid,
    output logic [31:0] axi_awaddr,
    input  logic        axi_awready,
    output logic        axi_wvalid,
    output logic [31:0] axi_wdata,
    output logic [3:0]  axi_wstrb,
    input  logic        axi_wready,
    input  logic        axi_bvalid,
    output logic        axi_bready,
    output logic        axi_arvalid,
    output logic [31:0] axi_araddr,
    input  logic        axi_arready,
    input  logic        axi_rvalid,
    input  logic [31:0] axi_rdata,
    output logic        axi_rready
);

    // ========================================================
    // Core Signals & Interrupt Wires
    // ========================================================
    wire [31:0] pg_riscv32_mp_dmdata_out;
    wire [31:0] pg_riscv32_mp_dmaddr_out;
    wire [31:0] pg_riscv32_mp_imaddr_out;
    wire        pg_riscv32_mp_dmreq_out;
    wire        pg_riscv32_mp_dmwen_out;
    wire [3:0]  pg_riscv32_mp_dmbe_out;
    wire        pg_riscv32_mp_imreq_out;
    
    wire        instr_gnt_o;
    wire        instr_rvalid_o;
    wire [31:0] instr_rdata_o;
   
    wire        data_gnt_o;
    wire        data_rvalid_o;
    wire [31:0] data_rdata_o;

    // Declare interrupt wires BEFORE instantiating the core
    wire        timer_irq;     
    wire        software_irq;  
  

    // ========================================================
    // 1. PRAGYA RISC-V Core
    // ========================================================
    pragya_core CORE(
        .pg_riscv32_mp_clk_in     (pg_riscv32_mp_clk_in),
        .pg_riscv32_mp_rst_in     (~pg_riscv32_mp_rst_in), 
        .pg_riscv32_mp_eirq_in    (ext_irq_in),    // Connected to PLIC
        .pg_riscv32_mp_tirq_in    (timer_irq),    // CONNECTED TO CLINT
        .pg_riscv32_mp_sirq_in    (software_irq), // CONNECTED TO CLINT
        
        .pg_riscv32_mp_instr_valid(instr_rvalid_o),
        .pg_riscv32_mp_data_valid (data_rvalid_o),
        .pg_riscv32_mp_instr_gnt  (instr_gnt_o),
        .pg_riscv32_mp_data_gnt   (data_gnt_o),
        .pg_riscv32_mp_instr_in   (instr_rdata_o),
        .pg_riscv32_mp_dmdata_in  (data_rdata_o),
        
        .pg_riscv32_mp_dmdata_out (pg_riscv32_mp_dmdata_out),
        .pg_riscv32_mp_dmaddr_out (pg_riscv32_mp_dmaddr_out),
        .pg_riscv32_mp_imaddr_out (pg_riscv32_mp_imaddr_out),
        .pg_riscv32_mp_dmwen_out  (pg_riscv32_mp_dmwen_out),
        .pg_riscv32_mp_dmbe_out   (pg_riscv32_mp_dmbe_out),
        .pg_riscv32_mp_dmreq_out  (pg_riscv32_mp_dmreq_out),
        .pg_riscv32_mp_imreq_out  (pg_riscv32_mp_imreq_out)
    );         

    // ========================================================
    // 2. Instruction Memory
    // ========================================================
    pragya_instr_mem_wrapper I_wrapper(
        .pg_riscv32_mp_clk_in (pg_riscv32_mp_clk_in),
        .pg_riscv32_mp_rst_in (~pg_riscv32_mp_rst_in), 
        .instr_req_i          (pg_riscv32_mp_imreq_out),
        .instr_addr_i         (pg_riscv32_mp_imaddr_out),
        .instr_gnt_o          (instr_gnt_o),
        .instr_rvalid_o       (instr_rvalid_o),
        .instr_rdata_o        (instr_rdata_o)
    );  
    
    // ========================================================
    // 3. Data OBI Demux (3 Ports) & Protocol Adapter
    // ========================================================
  
    OBI_BUS #( .OBI_CFG(obi_pkg::ObiDefaultConfig) ) core_data_bus ();
    OBI_BUS #( .OBI_CFG(obi_pkg::ObiDefaultConfig) ) mgr_buses [3] (); 

    // Skid buffer state registers
    reg        hold_state;
    reg        hold_req;
    reg [31:0] hold_addr;
    reg        hold_we;
    reg [3:0]  hold_be;
    reg [31:0] hold_wdata;
wire active_rst = ~pg_riscv32_mp_rst_in;
    always_ff @(posedge pg_riscv32_mp_clk_in or negedge pg_riscv32_mp_rst_in) begin
        if (!pg_riscv32_mp_rst_in) begin
            hold_state <= 1'b0;
            hold_req   <= 1'b0;
            hold_addr  <= 32'd0;
            hold_we    <= 1'b0;
            hold_be    <= 4'd0;
            hold_wdata <= 32'd0;
        end else begin
            // If we have an active request but no grant, enter HOLD state
            if (core_data_bus.req && !core_data_bus.gnt) begin
                if (!hold_state) begin
                    // First cycle of the stall: lock in the core's current outputs
                    hold_state <= 1'b1;
                    hold_req   <= 1'b1;
                    hold_addr  <= pg_riscv32_mp_dmaddr_out;
                    hold_we    <= pg_riscv32_mp_dmwen_out;
                    hold_be    <= pg_riscv32_mp_dmbe_out;
                    hold_wdata <= pg_riscv32_mp_dmdata_out;
                end
            end else if (core_data_bus.gnt) begin
                // Grant received, release the hold state
                hold_state <= 1'b0;
                hold_req   <= 1'b0;
            end
        end
    end

    // Drive the OBI bus: Use held signals if stalling, otherwise use live core signals
    assign core_data_bus.req   = hold_state ? hold_req   : pg_riscv32_mp_dmreq_out;
    assign core_data_bus.addr  = hold_state ? hold_addr  : pg_riscv32_mp_dmaddr_out;
    assign core_data_bus.we    = hold_state ? hold_we    : pg_riscv32_mp_dmwen_out;
    assign core_data_bus.be    = hold_state ? hold_be    : pg_riscv32_mp_dmbe_out;
    assign core_data_bus.wdata = hold_state ? hold_wdata : pg_riscv32_mp_dmdata_out;
    
    assign core_data_bus.aid   = '0;
    assign core_data_bus.a_optional = '0;

    // Route response signals back to the core
    assign data_gnt_o    = core_data_bus.gnt;
    assign data_rvalid_o = core_data_bus.rvalid;
    assign data_rdata_o  = core_data_bus.rdata;


    // 3-Way Address Decoder
    logic [1:0] demux_sel; // <--- FIXED: 2-bit selector added
    always_comb begin
        if (pg_riscv32_mp_dmaddr_out >= 32'h4000_0000) 
            demux_sel = 2'd2; // External AXI/APB (Port 2)
        else if (pg_riscv32_mp_dmaddr_out >= 32'h0200_0000 && pg_riscv32_mp_dmaddr_out < 32'h020C_0000) 
            demux_sel = 2'd1; // CLINT IP (Port 1)
        else 
            demux_sel = 2'd0; // Local SRAM (Port 0)
    end

    // Instantiate the Demux
    obi_demux_intf #(
        .ObiCfg      ( obi_pkg::ObiDefaultConfig ),
        .NumMgrPorts ( 3 ), 
        .NumMaxTrans ( 4 )
    ) i_data_demux (
        .clk_i             (pg_riscv32_mp_clk_in),
        .rst_ni            (pg_riscv32_mp_rst_in), 
        .sbr_port_select_i (demux_sel), // <--- FIXED: Passing the 2-bit selector
        .sbr_port          (core_data_bus),
        .mgr_ports         (mgr_buses)
    );

    // 4. Port 0: Data Memory Wrapper (Local SRAM)

    pragya_data_mem_wrapper D_wrapper(
        .pg_riscv32_mp_clk_in (pg_riscv32_mp_clk_in),
        .pg_riscv32_mp_rst_in (~pg_riscv32_mp_rst_in),
        .data_req_i           (mgr_buses[0].req),
        .data_we_i            (mgr_buses[0].we),
        .data_be_i            (mgr_buses[0].be),
        .data_addr_i          (mgr_buses[0].addr),
        .data_wdata_i         (mgr_buses[0].wdata),
        .data_gnt_o           (mgr_buses[0].gnt),
        .data_rvalid_o        (mgr_buses[0].rvalid),
        .data_rdata_o         (mgr_buses[0].rdata)
    );

    // 5. Port 1: CLINT (Timer & Software Interrupts)
 
    `OBI_TYPEDEF_ALL(obi, obi_pkg::ObiDefaultConfig)
    obi_req_t clint_req;
    obi_rsp_t clint_rsp;

    assign clint_req.req     = mgr_buses[1].req;
    assign clint_req.a.we    = mgr_buses[1].we;
    assign clint_req.a.be    = mgr_buses[1].be;
    assign clint_req.a.addr  = mgr_buses[1].addr;
    assign clint_req.a.wdata = mgr_buses[1].wdata;
    assign clint_req.a.aid   = '0; 

    assign mgr_buses[1].gnt        = clint_rsp.gnt;
    assign mgr_buses[1].rvalid     = clint_rsp.rvalid;
    assign mgr_buses[1].rdata      = clint_rsp.r.rdata;
    assign mgr_buses[1].err        = clint_rsp.r.err;
    assign mgr_buses[1].rid        = clint_rsp.r.rid;
    assign mgr_buses[1].r_optional = '0; 

    // Create a Real-Time Clock (RTC) pulse for the CLINT
    reg [7:0] rtc_counter;
    always @(posedge pg_riscv32_mp_clk_in) begin
        if (~active_rst) rtc_counter <= 8'd0;
        else rtc_counter <= rtc_counter + 1;
    end
    wire rtc_tick = rtc_counter[7];

    clint #(
        .obi_req_t(obi_req_t),
        .obi_rsp_t(obi_rsp_t)
    ) clint_inst (
        .clk_i          (pg_riscv32_mp_clk_in),
        .rst_ni         (pg_riscv32_mp_rst_in),
        .rtc_i          (rtc_tick),           
        .software_irq_o (software_irq),       
        .timer_irq_o    (timer_irq),         
        .obi_req_i      (clint_req),
        .obi_rsp_o      (clint_rsp)
    );
wire reset_active_high = ~pg_riscv32_mp_rst_in;

    // 6. Port 2: Official PULP OBI to AXI4 Bridge

    // 1. Unpack OBI_BUS interface into structs for the bridge
    obi_req_t axi_bridge_req;
    obi_rsp_t axi_bridge_rsp;

    assign axi_bridge_req.req     = mgr_buses[2].req;
    assign axi_bridge_req.a.we    = mgr_buses[2].we;
    assign axi_bridge_req.a.be    = mgr_buses[2].be;
    assign axi_bridge_req.a.addr  = mgr_buses[2].addr;
    assign axi_bridge_req.a.wdata = mgr_buses[2].wdata;
    assign axi_bridge_req.a.aid   = '0; 

    assign mgr_buses[2].gnt        = axi_bridge_rsp.gnt;
    assign mgr_buses[2].rvalid     = axi_bridge_rsp.rvalid;
    assign mgr_buses[2].rdata      = axi_bridge_rsp.r.rdata;
    assign mgr_buses[2].err        = axi_bridge_rsp.r.err;
    assign mgr_buses[2].rid        = axi_bridge_rsp.r.rid;
    assign mgr_buses[2].r_optional = '0; 

    // 2. Define unique types to prevent collisions with axi_pkg
    typedef logic [31:0] pragya_axi_addr_t;
    typedef logic [3:0]  pragya_axi_id_t;
    typedef logic [31:0] pragya_axi_data_t;
    typedef logic [3:0]  pragya_axi_strb_t;
    typedef logic        pragya_axi_user_t;

    // Generate the PULP AXI Structs
    `AXI_TYPEDEF_ALL(axi, pragya_axi_addr_t, pragya_axi_id_t, pragya_axi_data_t, pragya_axi_strb_t, pragya_axi_user_t)

    axi_req_t  axi_req_struct_o;
    axi_resp_t axi_resp_struct_i;

    // 3. Instantiate the Official PULP Bridge
   
    // We must pass the struct types so the module doesn't default to 1-bit wires!
    obi_to_axi #(
.MaxRequests ( 4 ),
        .obi_req_t  (obi_req_t),
        .obi_rsp_t (obi_rsp_t),
        .axi_req_t  (axi_req_t),
        .axi_rsp_t (axi_resp_t)
    ) i_obi2axi (
        .clk_i      (pg_riscv32_mp_clk_in),
        .rst_ni     (pg_riscv32_mp_rst_in),
        .obi_req_i  (axi_bridge_req),
        .obi_rsp_o  (axi_bridge_rsp),
        .axi_req_o  (axi_req_struct_o),
        .axi_rsp_i  (axi_resp_struct_i) 
    );
    // 4. Unpack the PULP AXI structs into your top module's flat pins
    assign axi_awvalid = axi_req_struct_o.aw_valid;
    assign axi_awaddr  = axi_req_struct_o.aw.addr;
    assign axi_resp_struct_i.aw_ready = axi_awready;

    assign axi_wvalid  = axi_req_struct_o.w_valid;
    assign axi_wdata   = axi_req_struct_o.w.data;
    assign axi_wstrb   = axi_req_struct_o.w.strb;
    assign axi_resp_struct_i.w_ready  = axi_wready;

    assign axi_bready  = axi_req_struct_o.b_ready;
    assign axi_resp_struct_i.b_valid  = axi_bvalid;
    assign axi_resp_struct_i.b        = '0; // Default OKAY response

    assign axi_arvalid = axi_req_struct_o.ar_valid;
    assign axi_araddr  = axi_req_struct_o.ar.addr;
    assign axi_resp_struct_i.ar_ready = axi_arready;

    assign axi_rready  = axi_req_struct_o.r_ready;
    assign axi_resp_struct_i.r_valid  = axi_rvalid;
    assign axi_resp_struct_i.r.data   = axi_rdata;
    assign axi_resp_struct_i.r.resp   = '0;   // Default OKAY response
    assign axi_resp_struct_i.r.last   = 1'b1; // Single beat responses for basic routing
endmodule
