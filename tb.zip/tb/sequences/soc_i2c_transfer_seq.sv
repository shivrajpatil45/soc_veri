`ifndef SOC_I2C_TRANSFER_SEQ_SV
`define SOC_I2C_TRANSFER_SEQ_SV

class soc_i2c_transfer_seq extends soc_base_seq;
  `uvm_object_utils(soc_i2c_transfer_seq)

  uvm_sequencer_base wr_seqr;
  uvm_sequencer_base rd_seqr;

  // I2C APB Register Map
  parameter bit [31:0] I2C_BASE = 32'h4000_1000;
  parameter bit [31:0] I2C_PRER = I2C_BASE + 32'h00;
  parameter bit [31:0] I2C_CTR  = I2C_BASE + 32'h04;
  parameter bit [31:0] I2C_RX   = I2C_BASE + 32'h08;
  parameter bit [31:0] I2C_SR   = I2C_BASE + 32'h0C;
  parameter bit [31:0] I2C_TX   = I2C_BASE + 32'h10;
  parameter bit [31:0] I2C_CR   = I2C_BASE + 32'h14;

  // Command bits
  localparam bit [7:0] CMD_START_WRITE = 8'h90; // STA=1, WR=1
  localparam bit [7:0] CMD_STOP_WRITE  = 8'h50; // STO=1, WR=1

  // Status bits
  localparam bit [7:0] SR_TIP   = 8'h02; // Transfer in progress
  localparam bit [7:0] SR_RXACK = 8'h80; // 0=ACK, 1=NACK

  function new(string name = "soc_i2c_transfer_seq");
    super.new(name);
  endfunction

  task wait_for_tip(output bit [31:0] sr_val);
    int timeout = 1000;
    do begin
      reg_read(I2C_SR, sr_val, rd_seqr);
      #200ns;
      timeout--;
    end while ((sr_val & SR_TIP) && timeout > 0);

    if (timeout == 0) begin
      `uvm_error("I2C_TX_SEQ", "Timeout waiting for TIP bit to clear in SR register!")
    end
  endtask

  virtual task body();
    bit [31:0] rdata;
    bit [6:0]  tgt_addr = 7'h68;
    bit [7:0]  test_payload = 8'h3C;

    `uvm_info("I2C_TX_SEQ", "=== Starting SoC I2C Master-to-Target VIP Transfer ===", UVM_LOW)

    // 1. Configure Prescaler for fast simulation clocking
    reg_write(I2C_PRER, 32'h0000_0004, wr_seqr);

    // 2. Enable Core
    reg_write(I2C_CTR, 32'h0000_0080, wr_seqr);
    #500ns;

    // 3. Write Target Address + WR bit (0xD0) with START command
    `uvm_info("I2C_TX_SEQ", $sformatf("Sending START + Target Address 0x%02X (WR)", tgt_addr), UVM_LOW)
    reg_write(I2C_TX, {24'h0, tgt_addr, 1'b0}, wr_seqr);
    reg_write(I2C_CR, {24'h0, CMD_START_WRITE}, wr_seqr);

    wait_for_tip(rdata);
    if (rdata & SR_RXACK)
      `uvm_error("I2C_TX_SEQ", "Target VIP returned NACK for Address byte!")
    else
      `uvm_info("I2C_TX_SEQ", "Target Address acknowledged (ACK received)", UVM_LOW)

    // 4. Send Data Byte + STOP command
    `uvm_info("I2C_TX_SEQ", $sformatf("Sending Data Byte 0x%02X + STOP", test_payload), UVM_LOW)
    reg_write(I2C_TX, {24'h0, test_payload}, wr_seqr);
    reg_write(I2C_CR, {24'h0, CMD_STOP_WRITE}, wr_seqr);

    wait_for_tip(rdata);
    if (rdata & SR_RXACK)
      `uvm_error("I2C_TX_SEQ", "Target VIP returned NACK for Data byte!")
    else
      `uvm_info("I2C_TX_SEQ", "Data byte acknowledged (ACK received)", UVM_LOW)

    #2us;
    `uvm_info("I2C_TX_SEQ", "=== I2C Master-to-Target Transfer Finished ===", UVM_LOW)
  endtask
endclass

`endif
