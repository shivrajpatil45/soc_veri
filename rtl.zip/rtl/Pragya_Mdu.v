module pragya_mdu(
    input  [31:0] rs_1_in,  // from reg file
    input  [31:0] rs_2_in,  // from reg file
    input  [2:0] mdu_op_in,  // from decoder
    output reg [31:0] mdu_result_out  // to wb_mux
    );
    
    wire signed [31:0] RD1_signed;
    wire signed [31:0] RD2_signed;

    assign RD1_signed = rs_1_in;
    assign RD2_signed = rs_2_in;

    wire signed [63:0] mul_ss = RD1_signed * RD2_signed;
    wire signed [63:0] mul_su = RD1_signed * $signed({1'b0, RD2_signed});
    wire        [63:0] mul_uu = rs_1_in * rs_2_in;

    always @(*) begin
        case (mdu_op_in)
         3'b000 : mdu_result_out = mul_ss [31:0];        // mul 
         3'b001 : mdu_result_out = mul_ss [63:32] ;      // mulh
         3'b010 : mdu_result_out = mul_su [63:32] ;      // mulhs
         3'b011 : mdu_result_out = mul_uu [63:32] ;      // mulhsu

         // div
         3'b100 : 
         if (RD2_signed == 0)
         mdu_result_out = 32'hFFFFFFFF;   // divide by zero case
         else if (RD1_signed == 32'h80000000 && RD2_signed == 32'hFFFFFFFF)
         mdu_result_out = RD1_signed;     // overflow case
         else
         mdu_result_out = RD1_signed / RD2_signed;
         
         
         //  divu

         3'b101 : 
         if (rs_2_in == 0)
         mdu_result_out = 32'hffffffff;
         else
          mdu_result_out = rs_1_in / rs_2_in;
         

         // rem 
         
         3'b110 :
         if (RD2_signed == 0)
         mdu_result_out = 32'hffffffff;
         else if (RD1_signed == 32'h80000000 && RD2_signed == 32'hffffffff) 
          mdu_result_out = RD1_signed;
         else
          mdu_result_out = RD1_signed % RD2_signed;

         // remu

         3'b111 : 
         if (rs_2_in == 0)
          mdu_result_out = 32'hffffffff;
         else
          mdu_result_out = rs_1_in % rs_2_in;
      
        endcase
        
    end 

endmodule










