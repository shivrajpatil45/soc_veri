`timescale 1ns/1ps

`include "axi/typedef.svh"
`include "axi/assign.svh"

module tb_top;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import soc_tb_pkg::*;
  import i3c_target_global_pkg::*;

  logic clk;
  logic rst_n;

  initial begin
    clk = 1'b0;
    forever #10 clk = ~clk;
  end

  initial begin
    rst_n = 1'b1;
    #5;
    rst_n = 1'b0;
    #100;
    @(negedge clk);
    rst_n = 1'b1;
  end

  Axi4LiteInterface axi_vif (
    .aclk    (clk),
    .aresetn (rst_n)
  );

  Axi4LiteMasterAgentBFM #(
    .ADDR_WIDTH (32),
    .DATA_WIDTH (32)
  ) axi_master_bfm (
    .axi4LiteMasterInterface (axi_vif.axi4LiteMasterInterface)
  );

  AXI_LITE #(
    .AXI_ADDR_WIDTH(32),
    .AXI_DATA_WIDTH(32)
  ) dut_axi_slv ();

  assign dut_axi_slv.aw_addr   = axi_vif.axi4LiteMasterInterface.axi4LiteMasterWriteInterface.awaddr;
  assign dut_axi_slv.aw_prot   = axi_vif.axi4LiteMasterInterface.axi4LiteMasterWriteInterface.awprot;
  assign dut_axi_slv.aw_valid  = axi_vif.axi4LiteMasterInterface.axi4LiteMasterWriteInterface.awvalid;
  assign axi_vif.axi4LiteMasterInterface.axi4LiteMasterWriteInterface.awready = dut_axi_slv.aw_ready;

  assign dut_axi_slv.w_data    = axi_vif.axi4LiteMasterInterface.axi4LiteMasterWriteInterface.wdata;
  assign dut_axi_slv.w_strb    = axi_vif.axi4LiteMasterInterface.axi4LiteMasterWriteInterface.wstrb;
  assign dut_axi_slv.w_valid   = axi_vif.axi4LiteMasterInterface.axi4LiteMasterWriteInterface.wvalid;
  assign axi_vif.axi4LiteMasterInterface.axi4LiteMasterWriteInterface.wready = dut_axi_slv.w_ready;

  assign axi_vif.axi4LiteMasterInterface.axi4LiteMasterWriteInterface.bresp  = dut_axi_slv.b_resp;
  assign axi_vif.axi4LiteMasterInterface.axi4LiteMasterWriteInterface.bvalid = dut_axi_slv.b_valid;
  assign dut_axi_slv.b_ready   = axi_vif.axi4LiteMasterInterface.axi4LiteMasterWriteInterface.bready;

  assign dut_axi_slv.ar_addr   = axi_vif.axi4LiteMasterInterface.axi4LiteMasterReadInterface.araddr;
  assign dut_axi_slv.ar_prot   = axi_vif.axi4LiteMasterInterface.axi4LiteMasterReadInterface.arprot;
  assign dut_axi_slv.ar_valid  = axi_vif.axi4LiteMasterInterface.axi4LiteMasterReadInterface.arvalid;
  assign axi_vif.axi4LiteMasterInterface.axi4LiteMasterReadInterface.arready = dut_axi_slv.ar_ready;

  assign axi_vif.axi4LiteMasterInterface.axi4LiteMasterReadInterface.rdata   = dut_axi_slv.r_data;
  assign axi_vif.axi4LiteMasterInterface.axi4LiteMasterReadInterface.rresp   = dut_axi_slv.r_resp;
  assign axi_vif.axi4LiteMasterInterface.axi4LiteMasterReadInterface.rvalid  = dut_axi_slv.r_valid;
  assign dut_axi_slv.r_ready   = axi_vif.axi4LiteMasterInterface.axi4LiteMasterReadInterface.rready;

  wire scl_bus;
  wire sda_bus;

  pullup(scl_bus);
  pullup(sda_bus);

  logic i2c_scl_out, i2c_scl_oen;
  logic i2c_sda_out, i2c_sda_oen;
  logic i2c_irq;

  assign scl_bus = (~i2c_scl_oen) ? i2c_scl_out : 1'bz;
  assign sda_bus = (~i2c_sda_oen) ? i2c_sda_out : 1'bz;

  i3c_if intf_target (
    .pclk   (clk),
    .areset (rst_n),
    .SCL    (scl_bus),
    .SDA    (sda_bus)
  );

  assign intf_target.SCL = (intf_target.scl_oen) ? intf_target.scl_o : 1'bz;
  assign intf_target.SDA = (intf_target.sda_oen) ? intf_target.sda_o : 1'bz;

  i3c_target_agent_bfm #(.target_ID(0)) i3c_target_agent_bfm_h (intf_target);

  peripherals_top #(
    .AddrWidth    (32),
    .DataWidth    (32),
    .NoApbSlaves  (7),
    .NoRules      (7)
  ) dut (
    .clk_i            (clk),
    .rst_ni           (rst_n),
    .dft_cg_enable_i  (1'b0),
    .axi_lite_slv     (dut_axi_slv),

    .uart_rx_i        (1'b1),
    .uart_tx_o        (),
    .uart_event_o     (),

    .i2c_scl_pad_i    (scl_bus),
    .i2c_scl_pad_o    (i2c_scl_out),
    .i2c_scl_padoen_o (i2c_scl_oen),
    .i2c_sda_pad_i    (sda_bus),
    .i2c_sda_pad_o    (i2c_sda_out),
    .i2c_sda_padoen_o (i2c_sda_oen),
    .i2c_interrupt_o  (i2c_irq),

    .timer_irq_o      (),

    .gpio_in_i        ('0),
    .gpio_out_o       (),
    .gpio_dir_o       (),
    .gpio_padcfg_o    (),
    .gpio_interrupt_o (),
    .gpio_in_sync_o   (),

    .spi_clk_o        (),
    .spi_csn0_o       (),
    .spi_csn1_o       (),
    .spi_csn2_o       (),
    .spi_csn3_o       (),
    .spi_mode_o       (),
    .spi_sdo0_o       (),
    .spi_sdo1_o       (),
    .spi_sdo2_o       (),
    .spi_sdo3_o       (),
    .spi_sdi0_i       (1'b0),
    .spi_sdi1_i       (1'b0),
    .spi_sdi2_i       (1'b0),
    .spi_sdi3_i       (1'b0),
    .spi_events_o     (),

    .plic_src_i       ('0),
    .plic_irq_o       ()
  );

  initial begin
    uvm_config_db#(virtual Axi4LiteInterface)::set(null, "*", "vif", axi_vif);
    run_test();
  end
endmodule
