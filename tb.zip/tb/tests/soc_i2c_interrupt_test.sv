`ifndef SOC_I2C_INTERRUPT_TEST_SV
`define SOC_I2C_INTERRUPT_TEST_SV

class soc_i2c_interrupt_test extends soc_base_test;
  `uvm_component_utils(soc_i2c_interrupt_test)

  function new(string name = "soc_i2c_interrupt_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  virtual task run_phase(uvm_phase phase);
    soc_i2c_interrupt_seq master_seq;
    i3c_target_writeOperationWith8bitsData_seq tgt_seq;

    phase.raise_objection(this);

    master_seq = soc_i2c_interrupt_seq::type_id::create("master_seq");
    tgt_seq    = i3c_target_writeOperationWith8bitsData_seq::type_id::create("tgt_seq");

    master_seq.wr_seqr = env.axi_master_env.axi4LiteWriteMasterEnv.axi4LiteMasterWriteAgent[0].axi4LiteMasterWriteSequencer;
    master_seq.rd_seqr = env.axi_master_env.axi4LiteReadMasterEnv.axi4LiteMasterReadAgent[0].axi4LiteMasterReadSequencer;

    fork
      tgt_seq.start(env.i3c_tgt_agent.i3c_target_seqr_h);
      master_seq.start(null);
    join_any
    disable fork;

    #500ns; // Drain time to let final bus stop complete
    phase.drop_objection(this);
  endtask
endclass

`endif
