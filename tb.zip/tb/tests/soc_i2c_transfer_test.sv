`ifndef SOC_I2C_TRANSFER_TEST_SV
`define SOC_I2C_TRANSFER_TEST_SV

class soc_i2c_transfer_test extends soc_base_test;
  `uvm_component_utils(soc_i2c_transfer_test)

  function new(string name = "soc_i2c_transfer_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  virtual task run_phase(uvm_phase phase);
    soc_i2c_transfer_seq                       m_seq;
    i3c_target_writeOperationWith8bitsData_seq tgt_seq;

    phase.raise_objection(this);

    m_seq   = soc_i2c_transfer_seq::type_id::create("m_seq");
    tgt_seq = i3c_target_writeOperationWith8bitsData_seq::type_id::create("tgt_seq");

    m_seq.wr_seqr = env.axi_master_env.axi4LiteWriteMasterEnv.axi4LiteMasterWriteAgent[0].axi4LiteMasterWriteSequencer;
    m_seq.rd_seqr = env.axi_master_env.axi4LiteReadMasterEnv.axi4LiteMasterReadAgent[0].axi4LiteMasterReadSequencer;

    fork
      begin
        tgt_seq.start(env.i3c_tgt_agent.i3c_target_seqr_h);
      end
      begin
        #300ns;
        m_seq.start(null);
      end
    join_any

    #2us;
    phase.drop_objection(this);
  endtask
endclass

`endif
