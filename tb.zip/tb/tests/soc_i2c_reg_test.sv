`ifndef SOC_I2C_REG_TEST_SV
`define SOC_I2C_REG_TEST_SV

class soc_i2c_reg_test extends soc_base_test;
  `uvm_component_utils(soc_i2c_reg_test)

  function new(string name = "soc_i2c_reg_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  virtual task run_phase(uvm_phase phase);
    soc_i2c_reg_seq seq;
    seq = soc_i2c_reg_seq::type_id::create("seq");

    phase.raise_objection(this);

    // Wait until reset is deasserted before driving bus traffic
    #150ns;

    seq.wr_seqr = env.axi_master_env.axi4LiteWriteMasterEnv.axi4LiteMasterWriteAgent[0].axi4LiteMasterWriteSequencer;
    seq.rd_seqr = env.axi_master_env.axi4LiteReadMasterEnv.axi4LiteMasterReadAgent[0].axi4LiteMasterReadSequencer;

    `uvm_info("TEST", "Executing I2C Register Sanity Test...", UVM_LOW)
    seq.start(null);

    #500ns;
    phase.drop_objection(this);
  endtask
endclass

`endif
