
module obi_ctrl(
    input wire clk,
    input wire rst,
    input wire req,  
    output wire gnt,
    output reg rvalid
);

    // We always grant the bus immediately
    assign gnt = 1'b1;

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            rvalid <= 1'b0;
        end else begin
            // Strictly follow the request by exactly 1 clock cycle
            rvalid <= req;
        end
    end

endmodule