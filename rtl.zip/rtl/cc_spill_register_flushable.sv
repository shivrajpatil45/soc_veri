// Copyright 2021 ETH Zurich and University of Bologna.
//
// Copyright and related rights are licensed under the Solderpad Hardware
// License, Version 0.51 (the "License"); you may not use this file except in
// compliance with the License. You may obtain a copy of the License at
// http://solderpad.org/licenses/SHL-0.51. Unless required by applicable law
// or agreed to in writing, software, hardware and materials distributed under
// this License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
// CONDITIONS OF ANY KIND, either express or implied. See the License for the
// specific language governing permissions and limitations under the License.
//
// Fabian Schuiki <fschuiki@iis.ee.ethz.ch>

`include "common_cells/assertions.svh"
`include "common_cells/registers.svh"

/// A register with handshakes that completely cuts any combinational paths
/// between the input and output. This spill register can be flushed.
module cc_spill_register_flushable #(
  parameter type data_t = logic,
  parameter bit  Bypass = 1'b0   // make this spill register transparent
) (
  input  logic  clk_i   , // Clock
  input  logic  rst_ni  , // Asynchronous reset active low
  input  logic  clr_i   , // Synchronous clear active high. Clears sequential logic without
                          // respecting handshakes.
  input  logic  valid_i ,
  input  logic  flush_i , // Flush the register by draining its contents. Mutually exclusive with
                          // valid_i.
  output logic  ready_o ,
  input  data_t data_i  ,
  output logic  valid_o ,
  input  logic  ready_i ,
  output data_t data_o
);

  if (Bypass) begin : gen_bypass
    assign valid_o = valid_i;
    assign ready_o = ready_i;
    assign data_o  = data_i;
  end else begin : gen_spill_reg
    // The A register.
    data_t a_data_q;
    logic a_full_q;
    logic a_fill, a_drain;

    `FFLARNC(a_data_q, data_i, a_fill, clr_i, data_t'('0), clk_i, rst_ni)
    `FFLARNC(a_full_q, a_fill, a_fill || a_drain, clr_i, '0, clk_i, rst_ni)

    // The B register.
    data_t b_data_q;
    logic b_full_q;
    logic b_fill, b_drain;

    `FFLARNC(b_data_q, a_data_q, b_fill, clr_i, data_t'('0), clk_i, rst_ni)
    `FFLARNC(b_full_q, b_fill,  b_fill || b_drain, clr_i, '0, clk_i, rst_ni)

    // Fill the A register when the A or B register is empty. Drain the A register
    // whenever it is full and being filled, or if a flush is requested.
    assign a_fill = valid_i && ready_o && (!flush_i);
    assign a_drain = (a_full_q && !b_full_q) || flush_i;

    // Fill the B register whenever the A register is drained, but the downstream
    // circuit is not ready. Drain the B register whenever it is full and the
    // downstream circuit is ready, or if a flush is requested.
    assign b_fill = a_drain && (!ready_i) && (!flush_i);
    assign b_drain = (b_full_q && ready_i) || flush_i;

    // We can accept input as long as register B is not full.
    // Note: flush_i and valid_i must not be high at the same time,
    // otherwise an invalid handshake may occur
    assign ready_o = !a_full_q || !b_full_q;

    // The unit provides output as long as one of the registers is filled.
    assign valid_o = a_full_q | b_full_q;

    // We empty the spill register before the slice register.
    assign data_o = b_full_q ? b_data_q : a_data_q;

    `ifndef COMMON_CELLS_ASSERTS_OFF
    `ASSERT(flush_valid, flush_i |-> ~valid_i, clk_i, !rst_ni,
           "Trying to flush and feed the spill register simultaneously. You will lose data!")
   `endif
  end
endmodule
