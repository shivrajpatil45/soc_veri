`ifndef SOC_I2C_READ_SEQ_SV
`define SOC_I2C_READ_SEQ_SV

class soc_i2c_read_seq extends soc_base_seq;
  `uvm_object_utils(soc_i2c_read_seq)

  uvm_sequencer_base wr_seqr;
  uvm_sequencer_base rd_seqr;

  parameter bit [31:0] I2C_BASE = 32'h4000_1000;
  parameter bit [31:0] I2C_PRER = I2C_BASE + 32'h00;
  parameter bit [31:0] I2C_CTR  = I2C_BASE + 32'h04;
  parameter bit [31:0] I2C_RX   = I2C_BASE + 32'h08;
  parameter bit [31:0] I2C_SR   = I2C_BASE + 32'h0C;
  parameter bit [31:0] I2C_TX   = I2C_BASE + 32'h10;
  parameter bit [31:0] I2C_CR   = I2C_BASE + 32'h14;

  parameter bit [7:0] CMD_START_WRITE    = 8'h90; // STA=1, WR=1
  parameter bit [7:0] CMD_READ_NACK_STOP = 8'h68; // STO=1, RD=1, ACK=1(NACK)

  function new(string name = "soc_i2c_read_seq");
    super.new(name);
  endfunction

  task wait_for_tip();
    bit [31:0] sr_val;
    do begin
      reg_read(I2C_SR, sr_val, rd_seqr);
    end while (sr_val[1] == 1'b1);
  endtask

  virtual task body();
    bit [6:0] tgt_addr = 7'h68;
    bit [31:0] rx_data;

    `uvm_info("I2C_RD_SEQ", "=== Starting I2C Master Read Sequence ===", UVM_LOW)

    // 1. Configure Prescaler
    reg_write(I2C_PRER, 32'h0000_0004, wr_seqr);

    // 2. Enable Core
    reg_write(I2C_CTR, 32'h0000_0080, wr_seqr);

    // 3. Send START + Target Address with RD bit (1'b1) -> 0xD1
    `uvm_info("I2C_RD_SEQ", $sformatf("Sending START + Target Address 0x%02X (RD)", tgt_addr), UVM_LOW)
    reg_write(I2C_TX, {24'h0, tgt_addr, 1'b1}, wr_seqr);
    reg_write(I2C_CR, {24'h0, CMD_START_WRITE}, wr_seqr);
    wait_for_tip();

    // 4. Issue READ command + NACK + STOP
    `uvm_info("I2C_RD_SEQ", "Issuing READ + NACK + STOP command", UVM_LOW)
    reg_write(I2C_CR, {24'h0, CMD_READ_NACK_STOP}, wr_seqr);
    wait_for_tip();

    // 5. Read back received byte from RX register
    reg_read(I2C_RX, rx_data, rd_seqr);
    `uvm_info("I2C_RD_SEQ", $sformatf("=== I2C Master Read Success! Received Data: 0x%02X ===", rx_data[7:0]), UVM_LOW)
  endtask
endclass

`endif
