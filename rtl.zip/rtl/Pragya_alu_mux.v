
module pragya_alu_mux ( input   [31:0]     rs_2_in,           // from register file
                        input   [31:0]     imm_in,           // from immediate generator
                        input              alu_src_in,       // from decoder
                        output  [31:0]     op_2_out          // operand 2 connected to alu 


);

assign op_2_out     =       alu_src_in ? imm_in  :  rs_2_in;

endmodule



