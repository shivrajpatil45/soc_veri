`ifndef SOC_TB_PKG_INCLUDED_
`define SOC_TB_PKG_INCLUDED_

package soc_tb_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  // AXI Master VIP packages
  import Axi4LiteWriteMasterGlobalPkg::*;
  import Axi4LiteMasterWritePkg::*;
  import Axi4LiteMasterWriteSeqPkg::*;
  import Axi4LiteWriteMasterEnvPkg::*;

  import Axi4LiteReadMasterGlobalPkg::*;
  import Axi4LiteMasterReadPkg::*;
  import Axi4LiteMasterReadSeqPkg::*;
  import Axi4LiteReadMasterEnvPkg::*;

  import Axi4LiteMasterVirtualSeqrPkg::*;
  import Axi4LiteMasterEnvPkg::*;

  // I3C/I2C Target VIP packages
  import i3c_target_global_pkg::*;
  import i3c_target_pkg::*;
  import i3c_target_seq_pkg::*;

  // SoC TB Components
  `include "soc_env.sv"
  `include "soc_base_seq.sv"
  `include "soc_i2c_reg_seq.sv"
  `include "soc_i2c_transfer_seq.sv"
  `include "soc_i2c_interrupt_seq.sv"
  `include "soc_i2c_read_seq.sv"
  `include "soc_base_test.sv"
  `include "soc_i2c_reg_test.sv"
  `include "soc_i2c_transfer_test.sv"
  `include "soc_i2c_interrupt_test.sv"
  `include "soc_i2c_read_test.sv"

endpackage : soc_tb_pkg

`endif
